# @lanehq/ben-runner

The CI runner for [Lane](https://lane.work)'s AI coding participant, Ben. It runs
[OpenCode](https://opencode.ai) in your GitHub Actions or GitLab CI job, works on a Lane task, and reports the
result back to Lane as a pull request or merge request.

**Preview release.** This package is intended for CI jobs dispatched by Lane. It requires a connected Lane project
and a provider-issued CI identity; it is not a standalone local coding assistant.

## How it works

1. A project Member or Admin submits a task comment mentioning **Ben · AI** in Lane.
2. Lane dispatches the repository's CI workflow with the task's run identifier.
3. The runner authenticates with Lane, retrieves the task context, and starts OpenCode on the recorded branch.
4. If OpenCode produces changes, the runner commits and pushes them. Lane creates or updates the PR/MR and
   reports the result on the task.

Follow-up comments continue the task's open PR/MR using a fresh OpenCode invocation. Ben does not merge changes,
deploy code, or complete the Lane task. You review and merge the result through your code provider.

Each run snapshots the saved task description, including live collaborative edits that have reached Lane's
WebSocket service but have not yet been compacted into PostgreSQL.

## Requirements

- A Lane project connected to a GitHub.com or GitLab.com repository.
- A Linux CI runner with Git at `/usr/bin/git` and Node.js 22.19.0 or later. The supplied templates configure these.
- OpenCode provider/model configuration and any credentials it requires, available to the CI job.
- Network access from the runner to Lane, your code provider, and your inference provider or custom endpoint.

Your accounts cover CI and inference costs. Lane does not supply inference credentials or select a model.

## Set up your repository

1. In Lane, open **Workspace settings → Code connections** and connect GitHub or GitLab as a workspace Owner/Admin.
2. Open **Project settings → Repository & Ben** and select the repository as a project Admin.
3. Copy the provider's template from Lane into the repository's default branch:

   | Provider       | Bundled template          | Repository destination                     |
   | -------------- | ------------------------- | ------------------------------------------ |
   | GitHub Actions | `templates/lane-ben.yml`  | `.github/workflows/lane-ben.yml`           |
   | GitLab CI      | `templates/gitlab-ci.yml` | Add the `lane_ben` job to `.gitlab-ci.yml` |

4. Map the inference credentials your OpenCode configuration needs into the job, using the examples below.
5. Commit the workflow, then click **Verify workflow** in Lane. This checks CI authentication without invoking
   a model. Once the repository shows **Ready**, submit a task comment using the **Ben · AI** mention suggestion.

The templates install the runner in a temporary directory, outside your application dependencies:

```sh
npm install --prefix /tmp/lane-ben --no-audit --no-fund @lanehq/ben-runner@0.1.1
node /tmp/lane-ben/node_modules/@lanehq/ben-runner/dist/index.js
```

Use these commands inside the supplied CI job, from the checked-out repository. Keep the template's dispatch rules,
OIDC configuration, permissions, concurrency, and timeouts. Lane supplies routing variables such as `BEN_RUN_ID`
and `BEN_API_URL`; no personal Lane access token or GitHub App private key belongs in this job.

For **GitHub**, retain the template's per-run environment name and commit-pinned actions. Ben runs only on Lane's
`repository_dispatch` event.

For **GitLab**, the authorizing user needs Maintainer access. Protect the default branch, enable **Allow Git push
requests to the repository** for CI job tokens, and ensure `workflow:rules` permits API pipelines. Job-token pushes
do not start another pipeline; configure any additional checks explicitly and exclude `lane_ben` from them.
Under **Settings → CI/CD → Variables**, set **Minimum role to use pipeline variables** to a role the authorizing
user holds. **No one allowed** prevents Ben's API pipeline dispatch.

Runner **0.1.1** uses **OpenCode 1.18.30** and callback protocol **1**. Use the exact versions in Lane's template;
changing the workflow requires another verification.

## OpenCode credentials and configuration

Configure your provider and model through OpenCode. The runner preserves that configuration and does not pass
`--model`, `--agent`, or permission overrides. Normal
`opencode.json`, instructions, agents, plugins, MCP servers, `OPENCODE_CONFIG`, `OPENCODE_CONFIG_DIR`,
`OPENCODE_CONFIG_CONTENT`, environment variables, and auth-file discovery remain effective.

Choose only the mappings your existing OpenCode configuration uses. **Zen and Go both use `OPENCODE_API_KEY`**;
OpenRouter uses `OPENROUTER_API_KEY`. Direct-provider examples include `ANTHROPIC_API_KEY` and `OPENAI_API_KEY`.
The model must already be configured normally; Lane neither chooses nor falls back to a different model/provider.

For GitHub, add one appropriate entry to the template's **Run Ben** `env`:

```yaml
env:
  OPENCODE_API_KEY: ${{ secrets.OPENCODE_API_KEY }} # Zen OR Go
  # OPENROUTER_API_KEY: ${{ secrets.OPENROUTER_API_KEY }}
  # ANTHROPIC_API_KEY: ${{ secrets.ANTHROPIC_API_KEY }}
  # OPENAI_API_KEY: ${{ secrets.OPENAI_API_KEY }}
```

For GitLab, use dedicated protected/masked/hidden variables, mapping their values explicitly in `lane_ben`:

```yaml
variables:
  OPENCODE_API_KEY: $BEN_OPENCODE_API_KEY # Zen OR Go
  # OPENROUTER_API_KEY: $BEN_OPENROUTER_API_KEY
  # ANTHROPIC_API_KEY: $BEN_ANTHROPIC_API_KEY
  # OPENAI_API_KEY: $BEN_OPENAI_API_KEY
```

GitLab variables can be inherited by jobs; keep unrelated deployment secrets out of the Ben job and
scope variables to the intended job/environment. The `BEN_*` source names above are removed from OpenCode's
child environment; their explicitly mapped provider names are retained.

For a normal OpenCode auth file, store JSON in GitHub secret `BEN_OPENCODE_AUTH_JSON`. Add that secret to the
Run Ben step and materialize it before invoking the runner, without printing it:

```yaml
env:
  BEN_AUTH_JSON: ${{ secrets.BEN_OPENCODE_AUTH_JSON }}
run: |
  export XDG_DATA_HOME="$RUNNER_TEMP/ben-data"
  mkdir -p "$XDG_DATA_HOME/opencode"
  trap 'rm -f "$XDG_DATA_HOME/opencode/auth.json"' EXIT
  node -e 'require("fs").writeFileSync(process.env.XDG_DATA_HOME+"/opencode/auth.json",process.env.BEN_AUTH_JSON,{mode:0o600})'
  unset BEN_AUTH_JSON
  npm install --prefix "$RUNNER_TEMP/lane-ben" --no-audit --no-fund @lanehq/ben-runner@0.1.1
  node "$RUNNER_TEMP/lane-ben/node_modules/@lanehq/ben-runner/dist/index.js"
```

For GitLab, create a protected **File** CI variable `BEN_AUTH_FILE` containing normal OpenCode auth JSON. Add
these commands before the template's install/runner commands, and preserve its rules/OIDC/timeout:

```yaml
before_script:
  - export XDG_DATA_HOME=/tmp/ben-data
  - mkdir -p "$XDG_DATA_HOME/opencode"
  - cp "$BEN_AUTH_FILE" "$XDG_DATA_HOME/opencode/auth.json"
  - chmod 600 "$XDG_DATA_HOME/opencode/auth.json"
  - unset BEN_AUTH_FILE
after_script:
  - rm -f /tmp/ben-data/opencode/auth.json
```

A custom OpenAI-compatible endpoint uses ordinary OpenCode configuration, for example:

```json
{
  "$schema": "https://opencode.ai/config.json",
  "provider": {
    "company": {
      "npm": "@ai-sdk/openai-compatible",
      "name": "Company inference",
      "options": {
        "baseURL": "https://inference.example.com/v1",
        "apiKey": "{env:COMPANY_INFERENCE_KEY}"
      },
      "models": { "your-model-id": { "name": "Your configured model" } }
    }
  },
  "model": "company/your-model-id"
}
```

Replace the illustrative endpoint/model with your existing configuration; map `COMPANY_INFERENCE_KEY` explicitly
in the selected CI job. A local endpoint must be reachable from that job's runner. No credentials are required
for an endpoint that does not use them. Missing credentials, provider/model errors, and interactive permissions
produce `failed` or `needs_input` instead of prompting Lane to choose a model or broaden permissions.

## Execution limits and results

| Limit                    | Value                    |
| ------------------------ | ------------------------ |
| Run deadline             | 60 minutes from creation |
| CI job timeout           | 70 minutes               |
| Repository size          | 2 GiB                    |
| Changed files            | 500                      |
| Task context             | 64 KiB                   |
| Reported command results | Up to 50                 |

Lane shows progress and supports cancellation. A run can finish with a PR/MR, no changes, a request for input,
a failure, cancellation, or a timeout. Reported command exits are separate from OpenCode's narrative summary;
when no command results are observed, verification is marked unconfirmed. Usage and cost, when available, are
OpenCode-reported metadata rather than a Lane invoice. Large reports may be truncated.

Cancellation before the runner authenticates finishes immediately in Lane. An already-dispatched CI job may
still start and fail authentication; it cannot continue the cancelled run. After authentication, cancellation
is acknowledged by the runner through its control polling.

## Credentials and repository trust

Run Ben only in repositories you trust, preferably on disposable runners with dedicated inference credentials
and spending limits. Repository code, OpenCode tools, plugins, and MCP servers can access credentials supplied
to the job and may send task context to external services.

The runner removes Lane and CI/Git credentials from OpenCode's child environment and obtains GitHub write
credentials after OpenCode exits. GitLab's job token remains available to the wrapper for checkout and push.
These controls do not isolate malicious processes sharing the same host or user account.

Lane receives bounded summaries, changed paths, and observed command results rather than raw terminal streams.
The runner redacts known environment/auth-file secrets and token formats from reports, but cannot guarantee
recognition of secrets hardcoded in arbitrary repository files. Store credentials in CI secrets or normal
OpenCode auth files and keep unrelated secrets out of the job.

## Troubleshooting

- **Workflow is not ready:** check that the template is on the default branch, CI can run, and the job can reach
  Lane. Run **Verify workflow** again after configuration changes.
- **CI authentication fails:** restore the template's OIDC audience, environment, dispatch rules, and version pins.
  Start a new run from Lane rather than rerunning an old CI job.
- **OpenCode fails or needs input:** check the repository's provider, model, credentials, and unattended permissions.
  The runner does not choose a fallback provider or bypass permission prompts.
- **Push or PR/MR creation fails:** check repository access and branch changes; on GitLab, also check job-token push
  settings. Inspect the branch before retrying if code was pushed but Lane could not record the PR/MR.

For OpenCode configuration details, see its [configuration guide](https://opencode.ai/docs/config/),
[provider documentation](https://opencode.ai/docs/providers/), and [CLI reference](https://opencode.ai/docs/cli/).
